import os
import json
import re
from google.cloud import bigquery
from google import genai
import functions_framework

bq_client = bigquery.Client()
project_id = os.environ.get('GOOGLE_CLOUD_PROJECT', 'atgeir-moae-dev')
dataset_id = os.environ.get('BQ_DATASET_ID', 'hr_dataset')

@functions_framework.http
def handle_candidate_data(request):
    if request.method == 'OPTIONS':
        return ('', 204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Access-Control-Max-Age': '3600',
        })

    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Content-Type': 'application/json',
    }

    try:
        data = request.get_json()
        if not data:
            return (json.dumps({'error': 'No JSON body'}), 400, headers)

        action = data.get('type')

        # ── MARK_INVITED ───────────────────────────────────────────────────────
        if action == 'MARK_INVITED':
            job_id         = data.get('jobId')
            candidate_id   = data.get('candidateId')
            candidate_name = data.get('candidateName', '')
            candidate_email= data.get('candidateEmail', '')
            round_name     = data.get('round', 'round1')

            if not all([job_id, candidate_id, round_name]):
                return (json.dumps({'error': 'Missing required fields'}), 400, headers)

            merge_query = f"""
                MERGE `{project_id}.{dataset_id}.candidate_slot_selections` T
                USING (
                    SELECT
                        @job_id         AS job_id,
                        @candidate_id   AS candidate_id,
                        @round          AS round,
                        @candidate_name AS candidate_name,
                        @candidate_email AS candidate_email
                ) S
                ON T.job_id = S.job_id
                    AND T.candidate_id = S.candidate_id
                    AND T.round = S.round
                WHEN MATCHED AND T.status NOT IN ('scheduled', 'advanced', 'rejected') THEN
                    UPDATE SET status = 'invited'
                WHEN NOT MATCHED THEN INSERT (
                    slot_id, job_id, candidate_id, candidate_name, candidate_email,
                    round, status, confirmed_at
                ) VALUES (
                    CONCAT(S.candidate_id, '_', S.round), S.job_id, S.candidate_id, S.candidate_name, S.candidate_email,
                    S.round, 'invited', CURRENT_TIMESTAMP()
                )
            """
            params = [
                bigquery.ScalarQueryParameter('job_id',          'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id',    'STRING', candidate_id),
                bigquery.ScalarQueryParameter('round',           'STRING', round_name),
                bigquery.ScalarQueryParameter('candidate_name',  'STRING', candidate_name),
                bigquery.ScalarQueryParameter('candidate_email', 'STRING', candidate_email),
            ]
            bq_client.query(merge_query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result()
            
            # ── Move candidate out of the Shortlisted phase ──
            update_cand_query = f"""
                UPDATE `{project_id}.{dataset_id}.candidates`
                SET candidate_result = 'Interview'
                WHERE job_id = @job_id AND candidate_id = @candidate_id
            """
            bq_client.query(update_cand_query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result()
            
            return (json.dumps({'success': True}), 200, headers)

        # ── SAVE_FEEDBACK ──────────────────────────────────────────────────────
        elif action == 'SAVE_FEEDBACK':
            job_id        = data.get('jobId')
            candidate_id  = data.get('candidateId')
            round_name    = data.get('round')
            rating        = data.get('rating')
            tech_skill    = data.get('techSkill', '')
            communication = data.get('communication', '')
            notes         = data.get('notes', '')
            verdict       = data.get('verdict')

            if not all([job_id, candidate_id, round_name, rating, verdict]):
                return (json.dumps({'error': 'Missing required fields'}), 400, headers)

            feedback_query = f"""
                MERGE `{project_id}.{dataset_id}.interview_feedback` T
                USING (
                    SELECT
                        @job_id        AS job_id,
                        @candidate_id  AS candidate_id,
                        @round         AS round,
                        @rating        AS rating,
                        @tech_skill    AS tech_skill,
                        @communication AS communication,
                        @notes         AS notes,
                        @verdict       AS verdict,
                        'Internal Panel'     AS interviewer_name,
                        CURRENT_TIMESTAMP()  AS submitted_at
                ) S
                ON T.job_id = S.job_id
                    AND T.candidate_id = S.candidate_id
                    AND T.round = S.round
                WHEN MATCHED THEN UPDATE SET
                    rating        = S.rating,
                    tech_skill    = S.tech_skill,
                    communication = S.communication,
                    notes         = S.notes,
                    verdict       = S.verdict,
                    submitted_at  = S.submitted_at
                WHEN NOT MATCHED THEN INSERT (
                    job_id, candidate_id, round, rating,
                    tech_skill, communication, notes,
                    verdict, interviewer_name, submitted_at
                ) VALUES (
                    S.job_id, S.candidate_id, S.round, S.rating,
                    S.tech_skill, S.communication, S.notes,
                    S.verdict, S.interviewer_name, S.submitted_at
                )
            """
            feedback_params = [
                bigquery.ScalarQueryParameter('job_id',        'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id',  'STRING', candidate_id),
                bigquery.ScalarQueryParameter('round',         'STRING', round_name),
                bigquery.ScalarQueryParameter('rating',        'INT64',  int(rating)),
                bigquery.ScalarQueryParameter('tech_skill',    'STRING', tech_skill),
                bigquery.ScalarQueryParameter('communication', 'STRING', communication),
                bigquery.ScalarQueryParameter('notes',         'STRING', notes),
                bigquery.ScalarQueryParameter('verdict',       'STRING', verdict),
            ]
            bq_client.query(feedback_query, job_config=bigquery.QueryJobConfig(query_parameters=feedback_params)).result()

            if verdict == 'advance':
                status_value = 'advanced'
            elif verdict == 'hold':
                status_value = 'on_hold'
            else:
                status_value = 'rejected'

            status_query = f"""
                MERGE `{project_id}.{dataset_id}.candidate_slot_selections` T
                USING (
                    SELECT
                        @job_id       AS job_id,
                        @candidate_id AS candidate_id,
                        @round        AS round,
                        @status       AS status,
                        CURRENT_TIMESTAMP() AS confirmed_at
                ) S
                ON T.job_id = S.job_id
                    AND T.candidate_id = S.candidate_id
                    AND T.round = S.round
                WHEN MATCHED THEN UPDATE SET
                    status       = S.status,
                    confirmed_at = S.confirmed_at
                WHEN NOT MATCHED THEN INSERT (
                    job_id, candidate_id, round, status, confirmed_at
                ) VALUES (
                    S.job_id, S.candidate_id, S.round, S.status, S.confirmed_at
                )
            """
            status_params = [
                bigquery.ScalarQueryParameter('job_id',        'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id',  'STRING', candidate_id),
                bigquery.ScalarQueryParameter('round',         'STRING', round_name),
                bigquery.ScalarQueryParameter('status',        'STRING', status_value),
            ]
            bq_client.query(status_query, job_config=bigquery.QueryJobConfig(query_parameters=status_params)).result()
            return (json.dumps({'success': True}), 200, headers)

        # ── GET_FULL_PROFILE ───────────────────────────────────────────────────
        elif action == 'GET_FULL_PROFILE':
            job_id       = data.get('jobId')
            candidate_id = data.get('candidateId')

            if not all([job_id, candidate_id]):
                return (json.dumps({'error': 'Missing jobId or candidateId'}), 400, headers)

            profile_params = [
                bigquery.ScalarQueryParameter('job_id',       'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id', 'STRING', candidate_id),
            ]

            timeline_query = f"""
                SELECT round, status, confirmed_at, interviewer_email
                FROM (
                    SELECT round, status, confirmed_at, interviewer_email,
                           ROW_NUMBER() OVER (PARTITION BY round ORDER BY confirmed_at DESC) AS rn
                    FROM `{project_id}.{dataset_id}.candidate_slot_selections`
                    WHERE job_id = @job_id AND candidate_id = @candidate_id
                )
                WHERE rn = 1
                ORDER BY confirmed_at ASC
            """
            timeline_rows = bq_client.query(timeline_query, job_config=bigquery.QueryJobConfig(query_parameters=profile_params)).result()
            timeline = [
                {
                    'round':              row.round,
                    'status':             row.status,
                    'confirmed_at':       row.confirmed_at.isoformat() if row.confirmed_at else None,
                    'interviewer_email':  row.interviewer_email,
                }
                for row in timeline_rows
            ]

            feedback_query = f"""
                SELECT round, rating, tech_skill, communication,
                       notes, verdict, interviewer_name, submitted_at
                FROM `{project_id}.{dataset_id}.interview_feedback`
                WHERE job_id = @job_id AND candidate_id = @candidate_id
                ORDER BY submitted_at ASC
            """
            feedback_rows = bq_client.query(feedback_query, job_config=bigquery.QueryJobConfig(query_parameters=profile_params)).result()
            feedback = [
                {
                    'round':            row.round,
                    'rating':           row.rating,
                    'tech_skill':       row.tech_skill,
                    'communication':    row.communication,
                    'notes':            row.notes,
                    'verdict':          row.verdict,
                    'interviewer_name': row.interviewer_name,
                    'submitted_at':     row.submitted_at.isoformat() if row.submitted_at else None,
                }
                for row in feedback_rows
            ]
            return (json.dumps({'timeline': timeline, 'feedback': feedback}), 200, headers)

        # ── CHECK_FEEDBACK ─────────────────────────────────────────────────────
        elif action == 'CHECK_FEEDBACK':
            job_id       = data.get('jobId')
            candidate_id = data.get('candidateId')
            round_name   = data.get('round')

            if not all([job_id, candidate_id, round_name]):
                return (json.dumps({'error': 'Missing required fields'}), 400, headers)

            check_query = f"""
                SELECT verdict, rating, tech_skill, communication, notes
                FROM `{project_id}.{dataset_id}.interview_feedback`
                WHERE job_id = @job_id AND candidate_id = @candidate_id AND round = @round
                LIMIT 1
            """
            check_params = [
                bigquery.ScalarQueryParameter('job_id',       'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id', 'STRING', candidate_id),
                bigquery.ScalarQueryParameter('round',        'STRING', round_name),
            ]
            rows = list(bq_client.query(check_query, job_config=bigquery.QueryJobConfig(query_parameters=check_params)).result())
            existing_verdict = rows[0].verdict if rows else None
            is_final = existing_verdict in ('advance', 'reject')
            is_hold  = existing_verdict == 'hold'

            previous_feedback = None
            if is_hold:
                previous_feedback = {
                    'rating':        rows[0].rating,
                    'techSkill':     rows[0].tech_skill,
                    'communication': rows[0].communication,
                    'notes':         rows[0].notes,
                }
            # Fetch candidate email/name — technical/hr rows may have blank email
            # (frontend didn't pass candidateEmail when saving those slots),
            # so look across all rounds and take the latest non-empty one.
            contact_query = f"""
                SELECT candidate_email, candidate_name
                FROM `{project_id}.{dataset_id}.candidate_slot_selections`
                WHERE job_id = @job_id AND candidate_id = @candidate_id
                  AND candidate_email IS NOT NULL AND candidate_email != ''
                ORDER BY confirmed_at DESC
                LIMIT 1
            """
            contact_params = [
                bigquery.ScalarQueryParameter('job_id',       'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id', 'STRING', candidate_id),
            ]
            contact_rows = list(bq_client.query(contact_query, job_config=bigquery.QueryJobConfig(query_parameters=contact_params)).result())
            candidate_email = contact_rows[0].candidate_email if contact_rows else ''
            candidate_name  = contact_rows[0].candidate_name  if contact_rows else ''

            return (json.dumps({
                'alreadySubmitted':  is_final,
                'isHold':            is_hold,
                'previousFeedback':  previous_feedback,
                'candidateEmail':    candidate_email,
                'candidateName':     candidate_name,
            }), 200, headers)

        # ── CHECK_PIPELINE_STATUS ──────────────────────────────────────────────
        elif action in ('CHECK_PIPELINE_STATUS', 'GET_JOB_STATUS'):
            job_id = data.get('jobId')
            if not job_id:
                return (json.dumps({'error': 'Missing jobId'}), 400, headers)

            status_query = f"""
                SELECT pipeline_status
                FROM `{project_id}.{dataset_id}.jobs`
                WHERE job_id = @job_id
                LIMIT 1
            """
            status_params = [bigquery.ScalarQueryParameter('job_id', 'STRING', job_id)]
            rows = list(bq_client.query(status_query, job_config=bigquery.QueryJobConfig(query_parameters=status_params)).result())
            current_status = rows[0].pipeline_status if rows and rows[0].pipeline_status else 'IDLE'
            return (json.dumps({'status': current_status}), 200, headers)

        # ── GET_RESUME_STATUS ───────────────────────────────────────────────────
        # Polled by the frontend to show live per-resume processing progress.
        elif action == 'GET_RESUME_STATUS':
            job_id    = data.get('jobId')
            file_name = data.get('fileName')

            if not all([job_id, file_name]):
                return (json.dumps({'error': 'Missing jobId or fileName'}), 400, headers)

            query = f"""
                SELECT step, error, updated_at
                FROM `{project_id}.{dataset_id}.resume_status`
                WHERE job_id = @job_id AND file_name = @file_name
                LIMIT 1
            """
            params = [
                bigquery.ScalarQueryParameter('job_id', 'STRING', job_id),
                bigquery.ScalarQueryParameter('file_name', 'STRING', file_name),
            ]
            rows = list(bq_client.query(query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result())

            if not rows:
                return (json.dumps({'success': True, 'step': None}), 200, headers)

            row = rows[0]
            return (json.dumps({
                'success': True,
                'step':    row.step,
                'error':   row.error or None,
            }), 200, headers)

        # ── GET_INTERVIEWERS ───────────────────────────────────────────────────
        elif action == 'GET_INTERVIEWERS':
            job_id     = data.get('jobId')
            round_name = data.get('round')

            if not job_id:
                return (json.dumps({'error': 'Missing jobId'}), 400, headers)

            where_round = "AND `round` = @round" if round_name else ""
            params = [bigquery.ScalarQueryParameter('job_id', 'STRING', job_id)]
            if round_name:
                params.append(bigquery.ScalarQueryParameter('round', 'STRING', round_name))

            query = f"""
                SELECT
                    Interviewer_id,
                    Interviewer_name,
                    Interviewer_email,
                    `round`,
                    role,
                    day,
                    start_time,
                    end_time,
                    work_mode,
                    status
                FROM `{project_id}.{dataset_id}.interviewer_slots`
                WHERE job_id = @job_id
                {where_round}
                ORDER BY `round`, Interviewer_name
            """
            rows = list(bq_client.query(
                query,
                job_config=bigquery.QueryJobConfig(query_parameters=params)
            ).result())

            # Group flat per-slot rows back into one entry per interviewer
            interviewers_map = {}
            for row in rows:
                key = (row.Interviewer_id, row.round)
                if key not in interviewers_map:
                    interviewers_map[key] = {
                        'id':          row.Interviewer_id,
                        'name':        row.Interviewer_name,
                        'email':       row.Interviewer_email,
                        'role':        row.role,          
                        'round':       row.round,
                        'work_mode':   row.work_mode,
                        'slotDetails': [],
                    }
                interviewers_map[key]['slotDetails'].append({
                    'day':        row.day,
                    'start_time': row.start_time,
                    'end_time':   row.end_time,
                    'status':     row.status,
                    'work_mode':  row.work_mode,
                })

            interviewers = list(interviewers_map.values())
            return (json.dumps({'success': True, 'interviewers': interviewers}), 200, headers)
        

        # ── GET_CANDIDATES ─────────────────────────────────────────────────────
        # Called by JobResultsPage to load all screening results from BQ.
        # Replaces ResultsStore (localStorage).
        # Returns candidates grouped by result type to match PipelineResult shape.
        elif action == 'GET_CANDIDATES':
            job_id = data.get('jobId')
            if not job_id:
                return (json.dumps({'error': 'Missing jobId'}), 400, headers)
            
            title_query = f"""
                SELECT title FROM `{project_id}.{dataset_id}.jobs`
                WHERE job_id = @job_id LIMIT 1
            """
            title_rows = list(bq_client.query(
                title_query,
                job_config=bigquery.QueryJobConfig(query_parameters=[bigquery.ScalarQueryParameter('job_id', 'STRING', job_id)])
            ).result())
            job_title = title_rows[0].title if title_rows else job_id

            query = f"""
                SELECT
                    candidate_id,
                    name,
                    email,
                    phone,
                    candidate_result,
                    screening_status,
                    ai_screening_results,
                    reject_reason
                FROM `{project_id}.{dataset_id}.candidates`
                WHERE job_id = @job_id
                  AND screening_status = 'COMPLETED'
            """
            params = [bigquery.ScalarQueryParameter('job_id', 'STRING', job_id)]
            rows = list(bq_client.query(
                query,
                job_config=bigquery.QueryJobConfig(query_parameters=params)
            ).result())

            all_candidates = []
            for row in rows:
                ai_data = {}
                if row.ai_screening_results:
                    if isinstance(row.ai_screening_results, str):
                        try: ai_data = json.loads(row.ai_screening_results)
                        except: pass
                    else:
                        ai_data = row.ai_screening_results

                all_candidates.append({
                    'candidate_id':        row.candidate_id,
                    'name':                row.name,
                    'email':               row.email,
                    'phone':               row.phone or '',
                    'candidate_result':    row.candidate_result,
                    'reject_reason':       row.reject_reason or '',
                    
                    'final_score':         float(ai_data.get('final_score', 0)),
                    'similarity_score':    float(ai_data.get('similarity_score', 0)),
                    'overall_result':      ai_data.get('overall_result', ''),
                    
                    'overall_reason':      ai_data.get('overall_reason', ''),
                    'human_review_reason': ai_data.get('human_review_reason', ''),
                    'failed_rules':        ai_data.get('failed_rules', []),
                    'flagged_rules':       ai_data.get('flagged_rules', []),
                    
                    'relevant_exp':        ai_data.get('relevant_exp', ''),
                    'must_have_pct':       float(ai_data.get('must_have_pct', 0)),
                    'must_have_skills':    ai_data.get('must_have_skills', []),
                    'must_have_missing':   ai_data.get('must_have_missing', []),
                    'good_to_have_pct':    float(ai_data.get('good_to_have_pct', 0)),
                    'good_to_have_missing': ai_data.get('good_to_have_missing', []),
                    'questions':           ai_data.get('questions', [])
                })

            all_candidates.sort(key=lambda x: x['final_score'], reverse=True)

            # Filter out rejected candidates from the main AI tabs
            rejected = [c for c in all_candidates if c['candidate_result'] == 'Rejected']
            referred = [c for c in all_candidates if c['candidate_result'] == 'Referred']
            passed   = [c for c in all_candidates if c['overall_result'] == 'PASS' and c['candidate_result'] not in ('Rejected', 'Referred')]
            review   = [c for c in all_candidates if c['overall_result'] == 'HUMAN_REVIEW' and c['candidate_result'] not in ('Rejected', 'Referred')]
            failed   = [c for c in all_candidates if c['overall_result'] not in ('PASS', 'HUMAN_REVIEW') and c['candidate_result'] not in ('Rejected', 'Referred')]
            top      = passed[:5]

            return (json.dumps({
                'success':          True,
                'job_title':        job_title,
                'top_candidates':   top,
                'all_passed':       passed,
                'all_human_review': review,
                'all_failed':       failed,
                'all_rejected':     rejected,
                'all_referred':     referred,
                'total_candidates': len(all_candidates),
                'passed':           len(passed),
                'human_review':     len(review),
                'failed':           len(failed),
                'rejected':         len(rejected),
                'referred':         len(referred),
            }), 200, headers)

        # ── GET_SHORTLISTED ────────────────────────────────────────────────────
        # Called by ShortlistedPage to load shortlisted candidates from BQ.
        # Replaces ShortlistStore (localStorage).
        elif action == 'GET_SHORTLISTED':
            job_id = data.get('jobId')
            if not job_id:
                return (json.dumps({'error': 'Missing jobId'}), 400, headers)

            query = f"""
                    SELECT
                        candidate_id,
                        name,
                        email,
                        phone,
                        candidate_result,
                        ai_screening_results
                    FROM `{project_id}.{dataset_id}.candidates`
                    WHERE job_id = @job_id
                        AND candidate_result IN ('Shortlisted', 'Referred', 'Interview', 'Selected', 'Hired')
                """
            params = [bigquery.ScalarQueryParameter('job_id', 'STRING', job_id)]
            rows = list(bq_client.query(
                query,
                job_config=bigquery.QueryJobConfig(query_parameters=params)
            ).result())

            candidates = []
            for row in rows:
                ai_data = {}
                if row.ai_screening_results:
                    if isinstance(row.ai_screening_results, str):
                        try:
                            ai_data = json.loads(row.ai_screening_results)
                        except:
                            pass
                    else:
                        ai_data = row.ai_screening_results

                candidates.append({
                    'candidate_id':      row.candidate_id,
                    'name':              row.name,
                    'email':             row.email,
                    'phone':             row.phone or '',
                    'candidate_result':  row.candidate_result,
                    'final_score':       float(ai_data.get('final_score', 0)),
                    'overall_result':    ai_data.get('overall_result', ''),
                    'must_have_pct':     float(ai_data.get('must_have_pct', 0)),
                    'must_have_skills':  ai_data.get('must_have_skills', []),
                    'must_have_missing': ai_data.get('must_have_missing', []),
                    'relevant_exp':      ai_data.get('relevant_exp', ''),
                    'good_to_have_pct':   float(ai_data.get('good_to_have_pct', 0)),
                    'good_to_have_missing': ai_data.get('good_to_have_missing', []),
                    'failed_rules':       ai_data.get('failed_rules', []),
                    'flagged_rules':      ai_data.get('flagged_rules', []),
                    'questions':          ai_data.get('questions', [])
                })
                
            # Sort by final score descending before returning
            candidates.sort(key=lambda x: x['final_score'], reverse=True)

            return (json.dumps({'success': True, 'candidates': candidates}), 200, headers)

        # ── UPDATE_JOB_STATUS ──────────────────────────────────────────────────
        elif action == 'UPDATE_JOB_STATUS':
            job_id = data.get('jobId')
            new_status = data.get('status')
            
            if not job_id or not new_status:
                return (json.dumps({'error': 'Missing jobId or status'}), 400, headers)
                
            update_query = f"""
                UPDATE `{project_id}.{dataset_id}.jobs`
                SET status = @status
                WHERE job_id = @job_id
            """
            params = [
                bigquery.ScalarQueryParameter('status', 'STRING', new_status),
                bigquery.ScalarQueryParameter('job_id', 'STRING', job_id),
            ]
            
            try:
                bq_client.query(update_query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result()
                return (json.dumps({'success': True}), 200, headers)
            except Exception as e:
                return (json.dumps({'error': str(e)}), 500, headers)
        
        elif action == 'REJECT_CANDIDATE':
            job_id       = data.get('jobId')
            candidate_id = data.get('candidateId')
            reason       = data.get('reason', '')

            if not all([job_id, candidate_id]):
                return (json.dumps({'error': 'Missing required fields'}), 400, headers)

            reject_query = f"""
                UPDATE `{project_id}.{dataset_id}.candidates`
                SET candidate_result = 'Rejected',
                    reject_reason = @reason
                WHERE job_id = @job_id AND candidate_id = @candidate_id
            """
            params = [
                bigquery.ScalarQueryParameter('job_id', 'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id', 'STRING', candidate_id),
                bigquery.ScalarQueryParameter('reason', 'STRING', reason),
            ]
            bq_client.query(reject_query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result()
            
            return (json.dumps({'success': True}), 200, headers)
        
        # ── GET_RESUME_KEY_NOTES ───────────────────────────────────────────────
        elif action == 'GET_RESUME_KEY_NOTES':
            job_id       = data.get('jobId')
            candidate_id = data.get('candidateId')

            if not all([job_id, candidate_id]):
                return (json.dumps({'error': 'Missing jobId or candidateId'}), 400, headers)

            # 1. Grab raw text directly from BQ
            q = f"""
                SELECT raw_resume_text
                FROM `{project_id}.{dataset_id}.candidates`
                WHERE job_id = @job_id AND candidate_id = @candidate_id
                LIMIT 1
            """
            q_params = [
                bigquery.ScalarQueryParameter('job_id', 'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id', 'STRING', candidate_id)
            ]
            rows = list(bq_client.query(q, job_config=bigquery.QueryJobConfig(query_parameters=q_params)).result())
            raw_text = rows[0].raw_resume_text if rows and rows[0].raw_resume_text else ""

            if not raw_text.strip():
                return (json.dumps({'error': 'No raw resume text stored for this candidate'}), 404, headers)

            # 2. Fast LLM Extraction
            import re
            from google import genai

            gemini = genai.Client(vertexai=True, project=project_id, location="us-central1")
            
            prompt = f"""
            Analyze the following raw resume text and extract executive Key Notes for an HR recruiter.
            Return STRICTLY a JSON object matching this exact structure:
            {{
              "summary": "A punchy 2-sentence professional overview",
              "top_skills": ["Skill 1", "Skill 2", "Skill 3", "Skill 4", "Skill 5"],
              "education": "Highest degree earned & University Name",
              "key_experience": ["Highlight milestone 1", "Major achievement 2", "Key responsibility 3"]
            }}

            Resume Text:
            {raw_text[:4500]}
            """

            resp = gemini.models.generate_content(model="gemini-2.5-flash", contents=prompt)

            # Strip markdown fences safely
            clean = re.sub(r"^```(?:json)?\s*", "", resp.text.strip())
            clean = re.sub(r"\s*```$", "", clean).strip()

            try:
                notes_json = json.loads(clean)
            except Exception:
                notes_json = {"summary": resp.text[:300], "top_skills": [], "education": "N/A", "key_experience": []}

            return (json.dumps({'success': True, 'notes': notes_json}), 200, headers)

                # ── SAVE_CANDIDATE_REVIEW ─────────────────────────────────────────────
        elif action == 'SAVE_CANDIDATE_REVIEW':
            job_id             = data.get('jobId')
            cand_id            = data.get('candidateId')
            round_name         = data.get('round')
            rating             = data.get('rating')
            process_rating     = data.get('processRating')
            clarity_rating     = data.get('clarityRating')
            interviewer_rating = data.get('interviewerRating')
            overall_exp_rating = data.get('overallExpRating')
            comments           = (data.get('comments') or '').strip()

            if not all([job_id, cand_id, round_name]) or rating is None:
                return (json.dumps({'error': 'Missing essential review parameters'}), 400, headers)

            # Page doesn't send candidateName — look it up the same way CHECK_FEEDBACK does
            contact_query = f"""
                SELECT candidate_name
                FROM `{project_id}.{dataset_id}.candidate_slot_selections`
                WHERE job_id = @job_id AND candidate_id = @cand_id
                  AND candidate_name IS NOT NULL AND candidate_name != ''
                ORDER BY confirmed_at DESC
                LIMIT 1
            """
            contact_params = [
                bigquery.ScalarQueryParameter('job_id',  'STRING', job_id),
                bigquery.ScalarQueryParameter('cand_id', 'STRING', cand_id),
            ]
            contact_rows = list(bq_client.query(contact_query, job_config=bigquery.QueryJobConfig(query_parameters=contact_params)).result())
            cand_name = contact_rows[0].candidate_name if contact_rows else ''

            # Existing table has no per-question columns, so fold the four
            # sub-ratings into advice_notes as a small prefix block, and store
            # the rounded overall average in experience_rating (INTEGER).
            breakdown_lines = []
            if process_rating is not None:
                breakdown_lines.append(f"Communication Before Interview: {process_rating}/5")
            if clarity_rating is not None:
                breakdown_lines.append(f"Clarity of Process: {clarity_rating}/5")
            if interviewer_rating is not None:
                breakdown_lines.append(f"Interviewer Professionalism: {interviewer_rating}/5")
            if overall_exp_rating is not None:
                breakdown_lines.append(f"Overall Experience: {overall_exp_rating}/5")

            breakdown_text = " | ".join(breakdown_lines)
            full_notes = f"[{breakdown_text}]" + (f"\n\n{comments}" if comments else "") if breakdown_text else comments

            insert_query = f"""
                INSERT INTO `{project_id}.{dataset_id}.candidate_reviews`
                (review_id, job_id, candidate_id, candidate_name, round, experience_rating, advice_notes, submitted_at)
                VALUES (GENERATE_UUID(), @job_id, @cand_id, @cand_name, @round_name, @rating, @notes, CURRENT_TIMESTAMP())
            """
            params = [
                bigquery.ScalarQueryParameter('job_id',     'STRING', job_id),
                bigquery.ScalarQueryParameter('cand_id',    'STRING', cand_id),
                bigquery.ScalarQueryParameter('cand_name',  'STRING', cand_name),
                bigquery.ScalarQueryParameter('round_name', 'STRING', round_name),
                bigquery.ScalarQueryParameter('rating',     'INTEGER', round(float(rating))),
                bigquery.ScalarQueryParameter('notes',      'STRING', full_notes),
            ]
            bq_client.query(insert_query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result()

            return (json.dumps({'success': True}), 200, headers)

                # ── CHECK_CANDIDATE_REVIEW ─────────────────────────────────────────────
        elif action == 'CHECK_CANDIDATE_REVIEW':
            job_id       = data.get('jobId')
            candidate_id = data.get('candidateId')
            round_name   = data.get('round')

            if not all([job_id, candidate_id, round_name]):
                return (json.dumps({'error': 'Missing required fields'}), 400, headers)

            check_query = f"""
                SELECT review_id
                FROM `{project_id}.{dataset_id}.candidate_reviews`
                WHERE job_id = @job_id AND candidate_id = @candidate_id AND round = @round
                LIMIT 1
            """
            check_params = [
                bigquery.ScalarQueryParameter('job_id',       'STRING', job_id),
                bigquery.ScalarQueryParameter('candidate_id', 'STRING', candidate_id),
                bigquery.ScalarQueryParameter('round',        'STRING', round_name),
            ]
            rows = list(bq_client.query(check_query, job_config=bigquery.QueryJobConfig(query_parameters=check_params)).result())

            return (json.dumps({'alreadySubmitted': len(rows) > 0}), 200, headers)
        
        else:
            return (json.dumps({'error': f'Unknown action: {action}'}), 400, headers)
        

    except Exception as e:
        print(f'Error in handle_candidate_data: {e}')
        return (json.dumps({'error': str(e)}), 500, headers)